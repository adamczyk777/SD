%Jakub Adamczyk

function y = function_handle1( t, x, epsilon )
%FUNCTION_HANDLE1 Summary of this function goes here
%   Detailed explanation goes here
  y=-x+epsilon*x^2;
end

