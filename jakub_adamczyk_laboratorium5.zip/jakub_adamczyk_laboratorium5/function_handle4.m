%Jakub Adamczyk

function result = function_handle4( t, x )
%FUNCTION_HANDLE4 Summary of this function goes here
%   Detailed explanation goes here
    result = zeros(size(x));
    result(1)=-x(1);
    result(2)=0;

end

